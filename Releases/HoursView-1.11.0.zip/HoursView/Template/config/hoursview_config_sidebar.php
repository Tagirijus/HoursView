<li <?= $this->app->checkMenuSelection('HoursViewController', 'show') ?>>
    <a href="/hoursview/config"><?= t('HoursView configuration') ?></a>
</li>
