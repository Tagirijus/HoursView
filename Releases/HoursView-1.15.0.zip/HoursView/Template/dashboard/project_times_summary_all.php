<?php

$times = $tagiTimes($user['id']);
$captions = $this->hoursViewHelper->getLevelCaptions();

require(__DIR__ . '/../hours_header.php');
